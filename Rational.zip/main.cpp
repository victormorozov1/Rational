#include "rational.h"
#include <iostream>

int main() {

  return 0;
}
